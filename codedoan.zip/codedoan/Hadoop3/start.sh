#!/bin/bash

# Kiểm tra xem semgrep đã được cài đặt chưa
semgrep --version &> /dev/null

if [ $? -eq 0 ]; then
    echo "Semgrep đã được cài đặt."
else
    echo "Semgrep chưa được cài đặt. Đang cài đặt..."
    python3 -m pip install semgrep

    # Kiểm tra lại xem cài đặt có thành công không
    if [ $? -eq 0 ]; then
        echo "Cài đặt semgrep thành công."
    else
        echo "Cài đặt semgrep thất bại. Vui lòng kiểm tra lại."
        exit 1
    fi
fi

# Tiếp tục với việc quét semgrep
echo "Bắt đầu quét..."
semgrep scan /hadoop
