from flask import Flask, render_template, jsonify
import logs
from modules.hadoop import Hadoop
import subprocess

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')
@app.route('/hd2')
def hd2():
    return render_template('hd2.html')

@app.route('/hd3')
def hd3():
    return render_template('hd3.html')
@app.route('/run_checks', methods=['POST'])
def run_checks():

    hadoop_checker = Hadoop("examples")  

    results = []


    def custom_logger(message):
        results.append(message)

  
    logs.INFO = custom_logger
    logs.ERROR = custom_logger
    logs.DEBUG = custom_logger
    logs.ISSUE = custom_logger
    logs.RECOMMENDATION = custom_logger

   
    hadoop_checker.check_conf()
    

    return jsonify(results=results)

@app.route('/run_shell_script', methods=['POST'])
def run_shell_script():
    try:
        # Thực thi script start.sh
        result = subprocess.run(['bash', 'chmod +x ../Hadoop3/start.sh'], capture_output=True, text=True)
        result = subprocess.run(['bash', '../Hadoop3/start.sh'], capture_output=True, text=True)
        return jsonify({"status": "success", "output": result.stdout})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)})


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
