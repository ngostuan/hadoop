from flask import Flask,  render_template, jsonify, request, Response
import logs
from modules.hadoop import Hadoop
import subprocess

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')
@app.route('/hd2')
def hd2():
    return render_template('hd2.html')

@app.route('/hd3')
def hd3():
    return render_template('hd3.html')
@app.route('/run_checks', methods=['POST'])
def run_checks():

    hadoop_checker = Hadoop("examples")  

    results = []


    def custom_logger(message):
        results.append(message)

  
    logs.INFO = custom_logger
    logs.ERROR = custom_logger
    logs.DEBUG = custom_logger
    logs.ISSUE = custom_logger
    logs.RECOMMENDATION = custom_logger

   
    hadoop_checker.check_conf()
    

    return jsonify(results=results)

@app.route('/run_command', methods=['POST'])
def run_command():
    # Nhận dữ liệu JSON từ client
    data = request.get_json()
    command = data.get('command')

    # Map các command đến lệnh thực thi thực tế
    commands_map = {
        'cat_file1': 'cat file1.txt',
        'cat_file2': 'cat file2.txt',
        'cat_file3': 'cat file3.txt',
        'run_script': 'bash ../Hadoop3/start.sh'
    }

    if command not in commands_map:
        return jsonify({'output': 'Invalid command'}), 400

    def generate():
        try:
            # Thực thi lệnh với subprocess
            process = subprocess.Popen(
                commands_map[command],
                shell=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                universal_newlines=True
            )

            # Đọc output từ stdout và trả về theo từng dòng
            for line in iter(process.stdout.readline, ''):
                yield line  # Yield từng dòng

            # Đọc lỗi từ stderr nếu có và trả về
            for line in iter(process.stderr.readline, ''):
                yield line  # Yield lỗi nếu có

            process.stdout.close()
            process.stderr.close()
            process.wait()

        except Exception as e:
            yield f"Error occurred: {str(e)}"

    return Response(generate(), content_type='text/plain;charset=utf-8')

@app.route('/run_command', methods=['GET'])
def run_shell_script():
    return Response(generate(), content_type='text/event-stream')


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
