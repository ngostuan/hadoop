from flask import Flask,  render_template, jsonify, request, Response
import logs
from modules.hadoop import Hadoop
import subprocess

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')
@app.route('/hd2')
def hd2():
    return render_template('hd2.html')

@app.route('/hd3')
def hd3():
    return render_template('hd3.html')
@app.route('/run_checks', methods=['POST'])
def run_checks():

    hadoop_checker = Hadoop("examples")  

    results = []


    def custom_logger(message):
        results.append(message)

  
    logs.INFO = custom_logger
    logs.ERROR = custom_logger
    logs.DEBUG = custom_logger
    logs.ISSUE = custom_logger
    logs.RECOMMENDATION = custom_logger

   
    hadoop_checker.check_conf()
    

    return jsonify(results=results)

# def generate():
#     # Use subprocess to run the shell script and capture output
#     process = subprocess.Popen(['bash', '../Hadoop3/start.sh'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    
#     # Stream the output line by line from stdout
#     for line in process.stdout:
#         yield f"data: {line.decode('utf-8').strip()}\n\n"
    
#     # Stream any error messages from stderr (if any)
#     for line in process.stderr:
#         yield f"data: {line.decode('utf-8').strip()}\n\n"
    
#     # Wait for the process to finish
#     process.wait()

# @app.route('/run_shell_script', methods=['GET'])
# def run_shell_script():
#     return Response(generate(), content_type='text/event-stream')


# Hàm generate để stream dữ liệu liên tục từ shell script
def generate():
    # Chạy script bằng subprocess
    process = subprocess.Popen(
        ['bash', '../Hadoop3/start.sh'],  # Chạy file start.sh
        stdout=subprocess.PIPE,          # Lấy stdout
        stderr=subprocess.PIPE,          # Lấy stderr
        universal_newlines=True          # Nhận output dạng text (thay vì bytes)
    )
    
    # Đọc từng dòng output từ stdout
    for line in iter(process.stdout.readline, ''):  # Đọc từng dòng đến khi hết
        yield f"data: {line.strip()}\n\n"  # Gửi dòng đến client
    
    # Đọc các lỗi (nếu có) từ stderr
    for line in iter(process.stderr.readline, ''):
        yield f"data: {line.strip()}\n\n"
    
    process.stdout.close()
    process.stderr.close()
    process.wait()  # Chờ script hoàn tất

@app.route('/run_shell_script', methods=['GET'])
def run_shell_script():
    return Response(generate(), content_type='text/event-stream')


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
