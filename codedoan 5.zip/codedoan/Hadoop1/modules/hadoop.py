
import interface
import logs
import utils
import os
import xml.etree.ElementTree
import sys



class Hadoop(interface.Interface):
    def __init__(self, dir=None):
        super().__init__()
        if dir is None:
            self.conf_path = self.get_paths(files_appear=[
                "core-site.xml",
                "hdfs-site.xml",
                "mapred-site.xml",
                "yarn-site.xml",
            ] )
        else:
            self.conf_path = dir
        logs.INFO(f"[INFO]: Evaluating directory {self.conf_path}")
        self.core_file = os.path.join(self.conf_path, "core-site.xml")
        self.core_obj = self.xml_conf_to_obj(self.core_file)
        self.hdfs_file = os.path.join(self.conf_path, "hdfs-site.xml")
        self.hdfs_obj = self.xml_conf_to_obj(self.hdfs_file)
        self.mr_file = os.path.join(self.conf_path, "mapred-site.xml")
        self.mr_obj = self.xml_conf_to_obj(self.mr_file)
        self.yarn_file = os.path.join(self.conf_path, "yarn-site.xml")
        self.yarn_obj = self.xml_conf_to_obj(self.yarn_file)
        self.conf_obj = {**self.core_obj, **self.hdfs_obj, **self.mr_obj, **self.yarn_obj}

    def enumerate_path(self):
        return list({
            *utils.whereis("hadoop"),
            "/usr/local/cellar/hadoop/3.2.1/libexec/etc/hadoop/", # homebrew
            "/local/hadoop/etc/hadoop", # apt,
            "/etc/hadoop", # apt
        })

    @staticmethod
    def xml_conf_to_obj(file):
        res = {}
        try:
            root = xml.etree.ElementTree.parse(file).getroot()
            props = root.findall(".//property")
            for prop in props:
                name = prop.find(".//name").text
                try:
                    value = prop.find(".//value").text
                    res[name]  = value
                except AttributeError:
                    continue
        except FileNotFoundError:
            logs.INFO(f"[INFO]: {file} not found, skipped.")
         
        except Exception as e:
            logs.ERROR(f"[ERROR]: {e}")
            sys.exit(0)
        return res

    def check_global_ac(self):
   
        logs.INFO("[INFO]: Kiểm tra global access control")
        auth_method = utils.get_item_from_obj(self.conf_obj, "hadoop.security.authentication", default="simple")
        if auth_method == "simple":
            logs.ISSUE("[ISSUE]:  Bất kể user nào có thể access the instance")
            logs.RECOMMENDATION("[RECOMM]: hadoop.security.authentication = kerberos")
        else:
            logs.DEBUG(f"[DEBUG]:  Phương thức xác thực [{auth_method}]:  được bật")
        if utils.get_item_from_obj(self.conf_obj, "hadoop.security.authorization", default="false") == "false":
            logs.ISSUE("[ISSUE]:  Phân quyền đang không được bật")
            logs.RECOMMENDATION("[RECOMM]: hadoop.security.authorization = true")
        else:
            logs.DEBUG("[DEBUG]:  Phân quyền được bật")

    def check_web_portal_ac(self):
        logs.INFO("[INFO]: Kiểm tra portal access control")
        auth_method = utils.get_item_from_obj(self.conf_obj, "hadoop.http.authentication.type", default="simple")
        if auth_method == "simple":
            logs.ISSUE("[ISSUE]: Bất kể user nào có thể access the web portal")
            logs.RECOMMENDATION("[RECOMM]: hadoop.http.authentication.type = kerberos")
            if utils.get_item_from_obj(self.conf_obj, "hadoop.http.authentication.simple.anonymous.allowed",
                                       default="true") == "true":
                logs.ISSUE("[ISSUE]: Anonymous user được cho phép để access web portal.")
                logs.RECOMMENDATION("[RECOMM]: hadoop.http.authentication.simple.anonymous.allowed = false")
        else:
            logs.DEBUG(f"[DEBUG]: Phương thức xác thực [{auth_method}]:  đang được bật")

    def check_cors(self):
        logs.INFO("[INFO]: Kiểm tra web portal cross origin policy")

        if utils.get_item_from_obj(self.conf_obj, "hadoop.http.cross-origin.enabled",
                                   default="false") == "true":
            allowed_origins = utils.split_ip(
                utils.get_item_from_obj(self.conf_obj, "hadoop.http.cross-origin.allowed-origins",
                                       default="true")
            )
            if "*" in allowed_origins:
                logs.ISSUE("[ISSUE]: Cross origin is wildcard.")
                logs.RECOMMENDATION("[RECOMM]:  / qualify hadoop.http.cross-origin.allowed-origins")
            else:
                logs.DEBUG(f"[DEBUG]: CORS đang được bật nhưng chỉ cho phép tới {','.join(allowed_origins)}")
        else:
            logs.DEBUG("[DEBUG]: CORS đang tắt")

    def check_ssl(self):
        logs.INFO("[INFO]: Kiểm tra SSL")

        if utils.get_item_from_obj(self.conf_obj, "hadoop.ssl.enabled",
                                   default="false") == "false":
            logs.ISSUE("[ISSUE]: SSL đang tắt.")
            logs.RECOMMENDATION("[RECOMM]: hadoop.ssl.enabled = true")
        else:
            logs.DEBUG("[DEBUG]: SSL đang bật.")

    def check_nfs_export_range(self):
        logs.INFO("[INFO]: Đang kiểm tra phạm vi export")

        allowed_hosts = utils.get_item_from_obj(self.conf_obj, "nfs.exports.allowed.hosts", default="* rw")
        if allowed_hosts == "* rw":
          logs.ISSUE("[ISSUE]: NFS đang mở cho internet để đọc và ghi.")
          logs.RECOMMENDATION("[RECOMM]: / hãy xác định rõ nfs.exports.allowed.hosts")
        else:
          logs.DEBUG(f"[DEBUG]: Quyền truy cập của NFS: {allowed_hosts}. Đánh giá dựa trên ngữ cảnh.")

    def check_registry_ac(self):
        logs.INFO("[INFO]: Đang kiểm tra registry access control")

        if utils.get_item_from_obj(self.conf_obj, "hadoop.registry.rm.enabled", default="false") == "true":
         if utils.get_item_from_obj(self.conf_obj, "hadoop.registry.secure", default="false") == "false":
            logs.ISSUE("[ISSUE]: registry.secure chưa được bật.")
            logs.RECOMMENDATION("[RECOMM]: hadoop.registry.secure = true")
         else:
            logs.DEBUG("[DEBUG]: Registry security đã được bật.")
        else:
         logs.DEBUG("[DEBUG]: Registry security không được bật.")

    def check_fs_permission(self):
     logs.INFO("[INFO]: Đang kiểm tra quyền HDFS")

     if utils.get_item_from_obj(self.conf_obj, "dfs.permissions.enabled", default="true") == "false":
        logs.ISSUE("[ISSUE]: HDFS không có kiểm soát truy cập. Mọi người có thể thực hiện các thao tác CURD trên instance.")
        logs.RECOMMENDATION("[RECOMM]: dfs.permissions.enabled = true")
     else:
        logs.DEBUG("[DEBUG]: Hệ thống phân quyền HDFS đã được bật.")
    
     if utils.get_item_from_obj(self.conf_obj, "dfs.namenode.acls.enabled", default="false") == "false":
        logs.ISSUE("[ISSUE]: ACLs của HDFS chưa được bật.")
        logs.RECOMMENDATION("[RECOMM]: dfs.namenode.acls.enabled = true")
     else:
        logs.DEBUG("[DEBUG]: ACLs của HDFS đã được bật.")


    def check_conf(self):
        self.check_cors()
        self.check_ssl()
        self.check_global_ac()
        self.check_web_portal_ac()
        self.check_registry_ac()
        self.check_fs_permission()
        self.check_nfs_export_range()
