# How to Run the Script

Follow the steps below to execute the script:

1. First, grant execute permission to the script by running the command:
   ```bash
   chmod +x run.sh
   ```

2. Then, execute the script by running:
   ```bash
   ./run.sh
   ```

Make sure you have the necessary dependencies installed before running the script.

---

**Written by L.V.Son**
