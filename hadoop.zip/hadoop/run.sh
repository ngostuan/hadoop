#!/bin/bash

# run docker compose
docker-compose build --no-cache
