from flask import Flask,  render_template, jsonify, request, Response
import logs
from modules.hadoop import Hadoop
import subprocess

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')
@app.route('/hd2')
def hd2():
    return render_template('hd2.html')

@app.route('/hd3')
def hd3():
    return render_template('hd3.html')
@app.route('/run_checks', methods=['POST'])
def run_checks():

    hadoop_checker = Hadoop("examples")  

    results = []


    def custom_logger(message):
        results.append(message)

  
    logs.INFO = custom_logger
    logs.ERROR = custom_logger
    logs.DEBUG = custom_logger
    logs.ISSUE = custom_logger
    logs.RECOMMENDATION = custom_logger

   
    hadoop_checker.check_conf()
    

    return jsonify(results=results)

@app.route('/run_shell_script', methods=['POST'])
def run_shell_script():
    def generate():
        # Sử dụng subprocess.Popen để chạy file start.sh và nhận kết quả theo thời gian thực
        subprocess.run(['chmod', '+x', './start.sh'], check=True)
        process = subprocess.Popen(
            ['bash', './start.sh'],  # Chạy file start.sh
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )

        # Đọc dữ liệu từ stdout (kết quả quét)
        for line in process.stdout:
            yield f"data: {line}\n\n"  # Gửi dữ liệu tới frontend

        process.stdout.close()
        process.wait()  # Đảm bảo process hoàn tất

    return Response(generate(), content_type='text/event-stream') 

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
